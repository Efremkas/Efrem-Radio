@echo off
setlocal
if exist "C:\Program Files\VideoLAN\VLC\libvlc.dll" (
  echo [OK] VLC 64-bit found: C:\Program Files\VideoLAN\VLC
  exit /b 0
)
if exist "%~dp0build\vlc\libvlc.dll" (
  echo [OK] Portable VLC runtime found next to the app.
  exit /b 0
)
echo [NOT FOUND] VLC/libVLC is not installed.
echo Install official VLC 64-bit, then run EfremRadio again.
echo Optional winget command:
echo   winget install --id VideoLAN.VLC -e
exit /b 1
