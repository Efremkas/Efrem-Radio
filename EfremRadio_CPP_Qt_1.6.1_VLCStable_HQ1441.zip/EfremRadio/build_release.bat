@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "QT_ROOT=C:\Qt\6.11.2\msvc2022_64"
set "CMAKE_BIN=C:\Qt\Tools\CMake_64\bin"
set "NINJA_BIN=C:\Qt\Tools\Ninja"
set "VCVARS64=C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"

if not exist "%QT_ROOT%\bin\windeployqt.exe" (
    echo ERROR: Qt was not found at %QT_ROOT%
    pause
    exit /b 1
)
if not exist "%CMAKE_BIN%\cmake.exe" (
    echo ERROR: CMake was not found at %CMAKE_BIN%
    pause
    exit /b 1
)
if not exist "%NINJA_BIN%\ninja.exe" (
    echo ERROR: Ninja was not found at %NINJA_BIN%
    pause
    exit /b 1
)

where cl.exe >nul 2>nul
if errorlevel 1 (
    if exist "%VCVARS64%" (
        echo Initializing Visual Studio x64 compiler...
        call "%VCVARS64%"
    ) else (
        echo ERROR: MSVC environment was not found.
        echo Expected: %VCVARS64%
        pause
        exit /b 1
    )
)

set "PATH=%CMAKE_BIN%;%NINJA_BIN%;%PATH%"

if exist build rmdir /s /q build

cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="%QT_ROOT%"
if errorlevel 1 goto :fail

cmake --build build
if errorlevel 1 goto :fail

"%QT_ROOT%\bin\windeployqt.exe" --release --compiler-runtime "build\EfremRadio.exe"
if errorlevel 1 goto :fail

rem Check that the Qt multimedia plugin directory was deployed.
if not exist "build\multimedia" (
    echo WARNING: build\multimedia was not created by windeployqt.
    echo The FFmpeg multimedia backend may not be deployed correctly.
)

echo.
echo ===============================================
echo Build completed successfully.
echo EXE: %CD%\build\EfremRadio.exe
echo ===============================================
pause
exit /b 0

:fail
echo.
echo Build failed.
pause
exit /b 1
