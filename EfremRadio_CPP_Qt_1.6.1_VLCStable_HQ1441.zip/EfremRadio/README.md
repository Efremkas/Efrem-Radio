# Efrem Radio 1.4 — FFmpeg Internet Radio Fix

Главное изменение: FFmpeg снова используется по умолчанию. Нативный Windows Media Foundation backend Qt 6.11 имеет ограниченную поддержку некоторых сетевых OGG/FLAC/Vorbis/Opus-потоков и может навсегда оставаться на «Подключение к радиостанции».

Дополнительно включается `QT_ENABLE_EXPERIMENTAL_CODECS=1` до загрузки Qt Multimedia, а зависшее подключение прерывается после 15 секунд и переподключается.

Запуск:
- `EfremRadio.exe` — FFmpeg (рекомендуется)
- `EfremRadio.exe --windows-backend` — Windows backend для диагностики
- `EfremRadio.exe --media-debug` — расширенный лог Qt Multimedia/FFmpeg

# Efrem Radio 1.3 — Native Stream Fix

**Что исправлено в 1.3:** на Windows приложение по умолчанию использует нативный Qt Windows multimedia backend вместо FFmpeg. Это сделано специально для интернет-радио, у которого FFmpeg в некоторых конфигурациях мог через 1–3 секунды перестать выдавать звук, продолжая показывать состояние «Воспроизведение». Также удалён бесконечный loop для live-потоков, добавлены более надёжные playback options и отдельный watchdog фактического аудиопотока для режима FFmpeg.

Обычный запуск использует Windows backend. Для диагностики/совместимости можно принудительно запустить FFmpeg: `EfremRadio.exe --ffmpeg`. Вернуть Windows backend явно: `EfremRadio.exe --windows-backend`.

# Efrem Radio 1.2

Лёгкий интернет-радиоплеер для Windows на C++ / Qt 6.

## Возможности

- Поиск радиостанций через Radio Browser API
- Воспроизведение интернет-потоков через Qt Multimedia
- Сворачивание в системный трей без остановки музыки
- Избранные радиостанции
- История последних 20 станций
- Ручное добавление станции по Stream URL
- Регулировка громкости
- HQ-режим: поиск и автоматический выбор потоков с повышенным реальным битрейтом
- Ползунок минимального HQ-битрейта от 128 до 1441 kbps
- Автоматический поиск более качественной версии уже играющей станции при включении HQ
- Локальное хранение настроек через QSettings
- Без Chromium/WebView — интерфейс на Qt Widgets

## Требования

- Windows 10/11 x64
- Qt 6.6+ (рекомендуется Qt 6.11.x MSVC 2022 64-bit)
- CMake 3.21+
- Visual Studio 2022/2026 с C++ Desktop workload
- Qt modules: Widgets, Network, Multimedia

## Сборка

Откройте **x64 Native Tools Command Prompt for VS** или обычный терминал, где доступны CMake и Qt.

Пример:

```bat
cd /d D:\EfremRadio
cmake -S . -B build -G "Ninja" -DCMAKE_PREFIX_PATH="C:\Qt\6.11.2\msvc2022_64"
cmake --build build --config Release
```

Для Visual Studio generator:

```bat
cmake -S . -B build -G "Visual Studio 18 2026" -A x64 -DCMAKE_PREFIX_PATH="C:\Qt\6.11.2\msvc2022_64"
cmake --build build --config Release
```

Если у вас Visual Studio 2022, используйте соответствующий generator.

## Развёртывание Qt DLL

После сборки Release:

```bat
C:\Qt\6.11.2\msvc2022_64\bin\windeployqt.exe build\Release\EfremRadio.exe
```

или путь к EXE, который создал ваш generator.

## Как пользоваться

1. Вкладка **Поиск** — введите название станции и нажмите `Найти`.
2. Двойной клик по результату запускает воспроизведение.
3. Кнопка `☆ В избранное` сохраняет текущую станцию.
4. `+ Добавить станцию` позволяет вставить прямой Stream URL.
5. Закрытие окна скрывает приложение в трей; звук продолжает играть.
6. Через значок в трее можно открыть программу, поставить на паузу или полностью выйти.
7. Кнопка `HQ` включает режим высокого качества. Ползунком задаётся минимальный желаемый битрейт от 128 до 1441 kbps.
8. Если текущая станция играет с более низким известным битрейтом, приложение попробует найти более качественный публичный поток с тем же названием и переключиться на него.


## 1.2 — стабильное интернет-воспроизведение

- Автоматическое переподключение при `StalledMedia`, `EndOfMedia`, сетевой ошибке или неожиданной остановке потока.
- Watchdog проверяет состояние потока каждые 2.5 секунды.
- Перед повторным подключением мультимедийный backend полностью сбрасывается, чтобы не оставаться на «полузакрытом» сетевом соединении.
- Повторные подключения используют плавную задержку до 10 секунд, поэтому недоступный сервер не получает десятки запросов подряд.
- Временные сетевые ошибки больше не показывают блокирующее окно: приложение восстанавливает поток само и показывает состояние в нижней строке.
- `build_release.bat` теперь сам подключает MSVC x64, CMake и Ninja для конфигурации Qt/Visual Studio, использованной при разработке.

## HQ-режим и битрейт

HQ-режим **не может искусственно превратить** поток 128/320 kbps в настоящий 1441 kbps. Качество определяется исходным потоком самой радиостанции.

При включённом HQ приложение:

- предпочитает станции с реальным битрейтом не ниже выбранного значения;
- сортирует найденные варианты по битрейту;
- скрывает варианты, которые не достигают выбранного порога;
- при включении HQ во время воспроизведения пытается найти вариант текущей станции с более высоким битрейтом.

Значения выше 320 kbps встречаются реже и обычно относятся к lossless/FLAC-потокам. Ползунок позволяет выбрать порог вплоть до 1441 kbps. Для обычного интернет-радио чаще встречаются 128, 192, 256 или 320 kbps. Практичный порог по умолчанию — 320 kbps.

Если HQ-вариант не найден, текущая радиостанция продолжает играть без изменений.

## API

Каталог радиостанций: https://www.radio-browser.info/

Приложение делает поиск через публичный Radio Browser API и получает только первые 50 релевантных результатов, поэтому не держит огромную базу в памяти.

## Примечания

- Некоторые станции периодически меняют stream URL или блокируют отдельные регионы.
- Некоторые потоки могут использовать кодек, который не поддерживается медиабэкендом конкретной Windows/Qt-сборки.
- Если поток не играет, попробуйте другую станцию либо добавьте её актуальный прямой URL вручную.
- Для максимально лёгкой фоновой работы приложение не загружает логотипы станций и не использует WebView.

## 1.5 Stable Playback

- Removed aggressive audio-buffer and live-position watchdogs that could falsely restart OGG/FLAC radio streams every few seconds.
- Short `StalledMedia` periods are now treated as normal buffering; reconnect happens only after a long 12-second stall.
- Reconnect attempts use slower backoff and are reset only after 30 seconds of uninterrupted playback.
- After repeated genuine failures, Efrem Radio asks Radio Browser for another stream URL for the same station and prefers AAC/MP3 128-320 kbps for compatibility.
- HQ remains available, but playback stability takes priority after repeated source failures.

## Version 1.6 - Stable VLC streaming backend

Qt Multimedia is still used as a fallback, but internet radio now prefers
**libVLC** when VLC 64-bit is installed. This change is specifically for live
Icecast/Shoutcast/OGG/FLAC/AAC streams that may start for a second or two and
then go silent in QMediaPlayer while Qt still reports PlayingState.

The app dynamically loads libVLC at runtime, so there is **no compile-time VLC
SDK dependency**. Build exactly as before. For stable playback install VLC
64-bit in the default location:

    C:\Program Files\VideoLAN\VLC

or set `VLC_HOME` to a folder containing `libvlc.dll` and `plugins`.

You can run `check_vlc.bat` to verify detection.

To force the old Qt backend for comparison:

    EfremRadio.exe --qt-backend

Portable packaging is also possible: place a legal VLC runtime under
`vlc\` or `runtime\vlc\` next to EfremRadio.exe (including the `plugins`
folder and applicable VLC license notices).
