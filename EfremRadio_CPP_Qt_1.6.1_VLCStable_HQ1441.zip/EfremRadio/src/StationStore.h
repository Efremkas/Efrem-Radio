#pragma once

#include <QObject>
#include <QList>
#include "Station.h"

class StationStore : public QObject {
    Q_OBJECT
public:
    explicit StationStore(QObject *parent = nullptr);

    QList<Station> favorites() const;
    QList<Station> customStations() const;
    QList<Station> history() const;

    bool isFavorite(const Station &station) const;
    void toggleFavorite(const Station &station);
    void addCustomStation(const Station &station);
    void removeCustomStation(const QString &streamUrl);
    void addToHistory(const Station &station);

signals:
    void favoritesChanged();
    void customStationsChanged();
    void historyChanged();

private:
    QList<Station> loadList(const QString &key) const;
    void saveList(const QString &key, const QList<Station> &list) const;
};
