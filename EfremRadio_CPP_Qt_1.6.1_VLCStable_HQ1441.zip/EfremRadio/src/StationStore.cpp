#include "StationStore.h"

#include <QSettings>
#include <QJsonArray>
#include <QJsonDocument>
#include <algorithm>

namespace {
constexpr const char *kFav = "stations/favorites";
constexpr const char *kCustom = "stations/custom";
constexpr const char *kHistory = "stations/history";
}

StationStore::StationStore(QObject *parent) : QObject(parent) {}

QList<Station> StationStore::loadList(const QString &key) const {
    QSettings s;
    const QByteArray raw = s.value(key).toByteArray();
    if (raw.isEmpty()) return {};
    const QJsonDocument doc = QJsonDocument::fromJson(raw);
    if (!doc.isArray()) return {};
    QList<Station> list;
    for (const auto &v : doc.array()) {
        if (v.isObject()) {
            Station st = Station::fromJson(v.toObject());
            if (st.isValid()) list.push_back(st);
        }
    }
    return list;
}

void StationStore::saveList(const QString &key, const QList<Station> &list) const {
    QJsonArray a;
    for (const auto &st : list) a.append(st.toJson());
    QSettings s;
    s.setValue(key, QJsonDocument(a).toJson(QJsonDocument::Compact));
}

QList<Station> StationStore::favorites() const { return loadList(kFav); }
QList<Station> StationStore::customStations() const { return loadList(kCustom); }
QList<Station> StationStore::history() const { return loadList(kHistory); }

bool StationStore::isFavorite(const Station &station) const {
    const auto list = favorites();
    return std::any_of(list.begin(), list.end(), [&](const Station &s) {
        return s.streamUrl == station.streamUrl;
    });
}

void StationStore::toggleFavorite(const Station &station) {
    if (!station.isValid()) return;
    auto list = favorites();
    auto it = std::find_if(list.begin(), list.end(), [&](const Station &s) { return s.streamUrl == station.streamUrl; });
    if (it != list.end()) list.erase(it);
    else list.prepend(station);
    saveList(kFav, list);
    emit favoritesChanged();
}

void StationStore::addCustomStation(const Station &station) {
    if (!station.isValid()) return;
    auto list = customStations();
    auto it = std::find_if(list.begin(), list.end(), [&](const Station &s) { return s.streamUrl == station.streamUrl; });
    if (it == list.end()) list.prepend(station);
    else *it = station;
    saveList(kCustom, list);
    emit customStationsChanged();
}

void StationStore::removeCustomStation(const QString &streamUrl) {
    auto list = customStations();
    list.erase(std::remove_if(list.begin(), list.end(), [&](const Station &s) { return s.streamUrl == streamUrl; }), list.end());
    saveList(kCustom, list);
    emit customStationsChanged();
}

void StationStore::addToHistory(const Station &station) {
    if (!station.isValid()) return;
    auto list = history();
    list.erase(std::remove_if(list.begin(), list.end(), [&](const Station &s) { return s.streamUrl == station.streamUrl; }), list.end());
    list.prepend(station);
    while (list.size() > 20) list.removeLast();
    saveList(kHistory, list);
    emit historyChanged();
}
