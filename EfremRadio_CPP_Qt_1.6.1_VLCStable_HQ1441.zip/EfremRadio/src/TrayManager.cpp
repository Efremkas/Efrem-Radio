#include "TrayManager.h"
#include "RadioPlayer.h"

#include <QMainWindow>
#include <QMenu>
#include <QApplication>
#include <QAction>
#include <QStyle>

TrayManager::TrayManager(QMainWindow *window, RadioPlayer *player, QObject *parent)
    : QObject(parent), m_window(window), m_player(player) {
    QIcon icon = qApp->style()->standardIcon(QStyle::SP_MediaVolume);
    m_tray.setIcon(icon);
    m_tray.setToolTip("Efrem Radio");

    auto *menu = new QMenu;
    auto *showAction = menu->addAction("Открыть Efrem Radio");
    m_playPauseAction = menu->addAction("Воспроизвести");
    menu->addSeparator();
    auto *quitAction = menu->addAction("Выход");
    m_tray.setContextMenu(menu);

    connect(showAction, &QAction::triggered, window, [window]() {
        window->showNormal();
        window->raise();
        window->activateWindow();
    });
    connect(m_playPauseAction, &QAction::triggered, player, &RadioPlayer::toggle);
    connect(quitAction, &QAction::triggered, qApp, &QApplication::quit);
    connect(player, &RadioPlayer::playbackStateChanged, this, [this](bool playing) {
        m_playPauseAction->setText(playing ? "Пауза" : "Воспроизвести");
    });
    connect(player, &RadioPlayer::stationChanged, this, [this](const Station &s) {
        m_tray.setToolTip(QString("Efrem Radio — %1").arg(s.name));
    });

    connect(&m_tray, &QSystemTrayIcon::activated, this, [window](QSystemTrayIcon::ActivationReason reason) {
        if (reason == QSystemTrayIcon::Trigger || reason == QSystemTrayIcon::DoubleClick) {
            window->showNormal();
            window->raise();
            window->activateWindow();
        }
    });

    m_tray.show();
}
