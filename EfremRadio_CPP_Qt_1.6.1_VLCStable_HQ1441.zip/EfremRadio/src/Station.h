#pragma once

#include <QString>
#include <QJsonObject>
#include <QVariantMap>

struct Station {
    QString id;
    QString name;
    QString streamUrl;
    QString homepage;
    QString favicon;
    QString country;
    QString language;
    QString codec;
    int bitrate = 0;
    bool custom = false;

    bool isValid() const { return !name.trimmed().isEmpty() && !streamUrl.trimmed().isEmpty(); }

    QVariantMap toVariantMap() const {
        return {
            {"id", id},
            {"name", name},
            {"streamUrl", streamUrl},
            {"homepage", homepage},
            {"favicon", favicon},
            {"country", country},
            {"language", language},
            {"codec", codec},
            {"bitrate", bitrate},
            {"custom", custom}
        };
    }

    static Station fromVariantMap(const QVariantMap &m) {
        Station s;
        s.id = m.value("id").toString();
        s.name = m.value("name").toString();
        s.streamUrl = m.value("streamUrl").toString();
        s.homepage = m.value("homepage").toString();
        s.favicon = m.value("favicon").toString();
        s.country = m.value("country").toString();
        s.language = m.value("language").toString();
        s.codec = m.value("codec").toString();
        s.bitrate = m.value("bitrate").toInt();
        s.custom = m.value("custom").toBool();
        return s;
    }

    QJsonObject toJson() const {
        QJsonObject o;
        o["id"] = id;
        o["name"] = name;
        o["streamUrl"] = streamUrl;
        o["homepage"] = homepage;
        o["favicon"] = favicon;
        o["country"] = country;
        o["language"] = language;
        o["codec"] = codec;
        o["bitrate"] = bitrate;
        o["custom"] = custom;
        return o;
    }

    static Station fromJson(const QJsonObject &o) {
        Station s;
        s.id = o.value("id").toString();
        s.name = o.value("name").toString();
        s.streamUrl = o.value("streamUrl").toString();
        s.homepage = o.value("homepage").toString();
        s.favicon = o.value("favicon").toString();
        s.country = o.value("country").toString();
        s.language = o.value("language").toString();
        s.codec = o.value("codec").toString();
        s.bitrate = o.value("bitrate").toInt();
        s.custom = o.value("custom").toBool();
        return s;
    }
};
