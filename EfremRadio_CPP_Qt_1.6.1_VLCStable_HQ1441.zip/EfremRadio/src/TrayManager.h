#pragma once

#include <QObject>
#include <QSystemTrayIcon>

class QMainWindow;
class QAction;
class RadioPlayer;

class TrayManager : public QObject {
    Q_OBJECT
public:
    TrayManager(QMainWindow *window, RadioPlayer *player, QObject *parent = nullptr);
    QSystemTrayIcon *trayIcon() { return &m_tray; }

private:
    QMainWindow *m_window;
    RadioPlayer *m_player;
    QSystemTrayIcon m_tray;
    QAction *m_playPauseAction = nullptr;
};
