#pragma once

#include <QDialog>
#include "Station.h"

class QLineEdit;

class AddStationDialog : public QDialog {
    Q_OBJECT
public:
    explicit AddStationDialog(QWidget *parent = nullptr);
    Station station() const;

private slots:
    void validateAndAccept();

private:
    QLineEdit *m_name;
    QLineEdit *m_url;
};
