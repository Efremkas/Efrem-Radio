#include "RadioPlayer.h"
#include "VlcBackend.h"

#include <QPlaybackOptions>
#include <QUrl>
#include <QtGlobal>
#include <chrono>

RadioPlayer::RadioPlayer(QObject *parent) : QObject(parent) {
    m_vlc = new VlcBackend(this);
    m_useVlc = m_vlc->initialize();

    m_reconnectTimer.setSingleShot(true);
    connect(&m_reconnectTimer, &QTimer::timeout, this, &RadioPlayer::reconnectNow);

    if (m_useVlc) {
        connect(m_vlc, &VlcBackend::started, this, [this]() {
            m_reconnectAttempts = 0;
            m_unstableReported = false;
            emit playbackStateChanged(true);
            emit mediaStatusText(QStringLiteral("Воспроизведение • стабильный VLC-движок"));
        });
        connect(m_vlc, &VlcBackend::statusText, this, &RadioPlayer::mediaStatusText);
        connect(m_vlc, &VlcBackend::playbackFailed, this, [this](const QString &reason) {
            if (!m_shouldPlay || m_userPaused || m_restarting)
                return;
            emit errorOccurred(reason);
            emit playbackStateChanged(false);
            scheduleReconnect(reason, 2000);
        });
    } else {
        setupQtFallback();
    }
}

void RadioPlayer::setupQtFallback() {
    m_player.setAudioOutput(&m_audio);
    m_audio.setVolume(m_volume / 100.0f);
    m_player.setLoops(QMediaPlayer::Once);

    QPlaybackOptions options;
    options.setPlaybackIntent(QPlaybackOptions::PlaybackIntent::Playback);
    options.setNetworkTimeout(std::chrono::milliseconds(30000));
    options.setProbeSize(4 * 1024 * 1024);
    m_player.setPlaybackOptions(options);

    connect(&m_player, &QMediaPlayer::playbackStateChanged, this,
            [this](QMediaPlayer::PlaybackState state) {
        const bool playing = state == QMediaPlayer::PlayingState;
        emit playbackStateChanged(playing);
        if (playing)
            emit mediaStatusText(QStringLiteral("Воспроизведение • Qt FFmpeg fallback"));
    });

    connect(&m_player, &QMediaPlayer::errorOccurred, this,
            [this](QMediaPlayer::Error, const QString &errorString) {
        if (!m_shouldPlay || m_userPaused)
            return;
        const QString reason = errorString.isEmpty()
                ? QStringLiteral("ошибка Qt Multimedia") : errorString;
        emit errorOccurred(reason);
        scheduleReconnect(reason, 2500);
    });

    connect(&m_player, &QMediaPlayer::mediaStatusChanged, this,
            [this](QMediaPlayer::MediaStatus status) {
        switch (status) {
            case QMediaPlayer::LoadingMedia:
                emit mediaStatusText(QStringLiteral("Подключение через Qt FFmpeg..."));
                break;
            case QMediaPlayer::BufferingMedia:
                emit mediaStatusText(QStringLiteral("Буферизация..."));
                break;
            case QMediaPlayer::BufferedMedia:
                emit mediaStatusText(QStringLiteral("Воспроизведение • Qt FFmpeg fallback"));
                break;
            case QMediaPlayer::StalledMedia:
                emit mediaStatusText(QStringLiteral("Поток временно буферизуется..."));
                break;
            case QMediaPlayer::EndOfMedia:
                if (m_shouldPlay && !m_userPaused)
                    scheduleReconnect(QStringLiteral("сервер завершил поток"), 2000);
                break;
            case QMediaPlayer::InvalidMedia:
                if (m_shouldPlay && !m_userPaused)
                    scheduleReconnect(QStringLiteral("поток недоступен или формат не поддерживается"), 3000);
                break;
            default:
                break;
        }
    });
}

QString RadioPlayer::engineDescription() const {
    if (m_useVlc)
        return QStringLiteral("VLC/libVLC");
    return QStringLiteral("Qt FFmpeg fallback (VLC не найден)");
}

void RadioPlayer::scheduleReconnect(const QString &reason, int minimumDelayMs) {
    if (!m_shouldPlay || m_userPaused || m_current.streamUrl.isEmpty() || m_reconnectTimer.isActive())
        return;

    ++m_reconnectAttempts;
    if (m_reconnectAttempts >= 3 && !m_unstableReported) {
        m_unstableReported = true;
        emit streamUnstable(m_current, reason);
    }

    const int delay = qMin(15000, minimumDelayMs + (m_reconnectAttempts - 1) * 2500);
    emit mediaStatusText(QStringLiteral("Поток оборвался. Повтор через %1 с... (%2)")
                             .arg(qMax(1, (delay + 999) / 1000))
                             .arg(reason));
    m_reconnectTimer.start(delay);
}

void RadioPlayer::reconnectNow() {
    if (!m_shouldPlay || m_userPaused || !m_current.isValid())
        return;

    m_restarting = true;
    emit mediaStatusText(QStringLiteral("Повторное подключение..."));
    if (m_useVlc) {
        m_vlc->stop();
        m_vlc->setVolume(m_volume);
        m_vlc->play(m_current.streamUrl);
    } else {
        m_player.stop();
        m_player.setSource(QUrl());
        QTimer::singleShot(250, this, [this]() {
            if (!m_shouldPlay || m_userPaused || !m_current.isValid()) {
                m_restarting = false;
                return;
            }
            m_player.setSource(QUrl(m_current.streamUrl));
            m_player.play();
            m_restarting = false;
        });
        return;
    }
    m_restarting = false;
}

void RadioPlayer::play(const Station &station) {
    if (!station.isValid())
        return;

    m_reconnectTimer.stop();
    m_reconnectAttempts = 0;
    m_unstableReported = false;
    m_shouldPlay = true;
    m_userPaused = false;
    m_restarting = false;
    m_current = station;
    emit stationChanged(m_current);

    if (m_useVlc) {
        m_vlc->setVolume(m_volume);
        if (!m_vlc->play(station.streamUrl)) {
            const QString reason = m_vlc->lastError().isEmpty()
                    ? QStringLiteral("VLC не смог открыть поток") : m_vlc->lastError();
            emit errorOccurred(reason);
            scheduleReconnect(reason, 2500);
        } else {
            emit mediaStatusText(QStringLiteral("Подключение к радиостанции через VLC..."));
        }
        return;
    }

    emit mediaStatusText(QStringLiteral("VLC не найден — используется Qt FFmpeg fallback. Для стабильного радио установите VLC 64-bit."));
    m_player.stop();
    m_player.setSource(QUrl());
    QTimer::singleShot(200, this, [this, station]() {
        if (!m_shouldPlay || m_userPaused || m_current.streamUrl != station.streamUrl)
            return;
        m_player.setSource(QUrl(station.streamUrl));
        m_player.play();
    });
}

void RadioPlayer::pause() {
    m_userPaused = true;
    m_shouldPlay = false;
    m_reconnectTimer.stop();
    if (m_useVlc)
        m_vlc->pause();
    else
        m_player.pause();
    emit playbackStateChanged(false);
    emit mediaStatusText(QStringLiteral("Пауза"));
}

void RadioPlayer::resume() {
    if (!m_current.isValid())
        return;
    m_shouldPlay = true;
    m_userPaused = false;
    m_reconnectAttempts = 0;
    m_unstableReported = false;
    if (m_useVlc)
        m_vlc->resume();
    else {
        if (m_player.source().isEmpty())
            m_player.setSource(QUrl(m_current.streamUrl));
        m_player.play();
    }
}

void RadioPlayer::stop() {
    m_shouldPlay = false;
    m_userPaused = false;
    m_reconnectTimer.stop();
    m_reconnectAttempts = 0;
    m_unstableReported = false;
    if (m_useVlc)
        m_vlc->stop();
    else
        m_player.stop();
    emit playbackStateChanged(false);
    emit mediaStatusText(QStringLiteral("Остановлено"));
}

void RadioPlayer::toggle() {
    if (m_userPaused || !m_shouldPlay || !isPlaying())
        resume();
    else
        pause();
}

void RadioPlayer::setVolume(int percent) {
    m_volume = qBound(0, percent, 100);
    if (m_useVlc)
        m_vlc->setVolume(m_volume);
    else
        m_audio.setVolume(m_volume / 100.0f);
}

bool RadioPlayer::isPlaying() const {
    if (m_useVlc)
        return m_vlc->isPlaying();
    return m_player.playbackState() == QMediaPlayer::PlayingState;
}

int RadioPlayer::volume() const {
    return m_volume;
}
