#pragma once

#include <QObject>
#include <QLibrary>
#include <QTimer>
#include <QElapsedTimer>
#include <QString>

class VlcBackend : public QObject {
    Q_OBJECT
public:
    explicit VlcBackend(QObject *parent = nullptr);
    ~VlcBackend() override;

    bool initialize();
    bool isAvailable() const { return m_instance != nullptr; }
    QString libraryPath() const { return m_libraryPath; }
    QString lastError() const { return m_lastError; }

    bool play(const QString &url);
    void pause();
    void resume();
    void stop();
    void setVolume(int percent);
    bool isPlaying() const;
    bool isPaused() const { return m_paused; }

signals:
    void started();
    void statusText(const QString &text);
    void playbackFailed(const QString &reason);

private:
    using FnNew = void *(*)(int, const char *const *);
    using FnRelease = void (*)(void *);
    using FnMediaNewLocation = void *(*)(void *, const char *);
    using FnMediaRelease = void (*)(void *);
    using FnMediaAddOption = void (*)(void *, const char *);
    using FnPlayerNewFromMedia = void *(*)(void *);
    using FnPlayerRelease = void (*)(void *);
    using FnPlayerPlay = int (*)(void *);
    using FnPlayerSetPause = void (*)(void *, int);
    using FnPlayerIsPlaying = int (*)(void *);
    using FnPlayerStop = void (*)(void *);
    using FnAudioSetVolume = int (*)(void *, int);
    using FnErrmsg = const char *(*)();

    QString findVlcLibrary() const;
    bool resolveSymbols();
    void destroyPlayer();
    QString vlcError(const QString &fallback) const;

    QLibrary m_library;
    QString m_libraryPath;
    QString m_lastError;

    void *m_instance = nullptr;
    void *m_media = nullptr;
    void *m_player = nullptr;

    FnNew pNew = nullptr;
    FnRelease pRelease = nullptr;
    FnMediaNewLocation pMediaNewLocation = nullptr;
    FnMediaRelease pMediaRelease = nullptr;
    FnMediaAddOption pMediaAddOption = nullptr;
    FnPlayerNewFromMedia pPlayerNewFromMedia = nullptr;
    FnPlayerRelease pPlayerRelease = nullptr;
    FnPlayerPlay pPlayerPlay = nullptr;
    FnPlayerSetPause pPlayerSetPause = nullptr;
    FnPlayerIsPlaying pPlayerIsPlaying = nullptr;
    FnPlayerStop pPlayerStop = nullptr;
    FnAudioSetVolume pAudioSetVolume = nullptr;
    FnErrmsg pErrmsg = nullptr;

    QTimer m_pollTimer;
    QElapsedTimer m_connectTimer;
    QElapsedTimer m_notPlayingSince;
    QString m_url;
    bool m_shouldPlay = false;
    bool m_paused = false;
    bool m_everPlayed = false;
    bool m_failureReported = false;
    int m_volume = 50;
};
