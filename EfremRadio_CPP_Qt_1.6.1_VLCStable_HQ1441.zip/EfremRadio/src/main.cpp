#include <QApplication>
#include <QCoreApplication>
#include <QSystemTrayIcon>
#include <QMessageBox>
#include <QByteArray>
#include <QString>
#include "MainWindow.h"

int main(int argc, char *argv[]) {
    // Internet radio is most compatible with Qt's FFmpeg backend. The native
    // Windows Media Foundation backend has limited support for some network
    // OGG/FLAC/Vorbis/Opus streams and can remain stuck in LoadingMedia.
    bool forceWindows = false;
    bool forceFfmpeg = false;
    bool forceQt = false;
    bool mediaDebug = false;

    for (int i = 1; i < argc; ++i) {
        const QString arg = QString::fromLocal8Bit(argv[i]);
        if (arg.compare("--windows-backend", Qt::CaseInsensitive) == 0)
            forceWindows = true;
        else if (arg.compare("--ffmpeg", Qt::CaseInsensitive) == 0)
            forceFfmpeg = true;
        else if (arg.compare("--qt-backend", Qt::CaseInsensitive) == 0)
            forceQt = true;
        else if (arg.compare("--media-debug", Qt::CaseInsensitive) == 0)
            mediaDebug = true;
    }

    if (forceQt)
        qputenv("EFREM_RADIO_ENGINE", QByteArrayLiteral("qt"));

    if (forceWindows && !forceFfmpeg)
        qputenv("QT_MEDIA_BACKEND", QByteArrayLiteral("windows"));
    else
        qputenv("QT_MEDIA_BACKEND", QByteArrayLiteral("ffmpeg"));

    // Many public radio streams use Vorbis/Opus in OGG containers. Qt's
    // bundled FFmpeg can keep some such decoders behind this opt-in switch.
    if (qEnvironmentVariableIsEmpty("QT_ENABLE_EXPERIMENTAL_CODECS"))
        qputenv("QT_ENABLE_EXPERIMENTAL_CODECS", QByteArrayLiteral("1"));

    if (mediaDebug) {
        qputenv("QT_FFMPEG_DEBUG", QByteArrayLiteral("1"));
        qputenv("QT_LOGGING_RULES", QByteArrayLiteral("*.multimedia.*=true;*.ffmpeg.*=true"));
    }

    QApplication app(argc, argv);
    QCoreApplication::setOrganizationName("EfremApps");
    QCoreApplication::setOrganizationDomain("local.efremradio");
    QCoreApplication::setApplicationName("EfremRadio");
    QCoreApplication::setApplicationVersion("1.6.0");
    QApplication::setQuitOnLastWindowClosed(false);

    if (!QSystemTrayIcon::isSystemTrayAvailable()) {
        QMessageBox::warning(nullptr, "Efrem Radio",
                             "Системный трей недоступен. Фоновый режим может работать некорректно.");
    }

    MainWindow window;
    window.show();
    return app.exec();
}
