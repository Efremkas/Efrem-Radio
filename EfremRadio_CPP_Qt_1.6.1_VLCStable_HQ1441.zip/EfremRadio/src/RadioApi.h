#pragma once

#include <QObject>
#include <QNetworkAccessManager>
#include <QList>
#include "Station.h"

class RadioApi : public QObject {
    Q_OBJECT
public:
    explicit RadioApi(QObject *parent = nullptr);

    // minBitrate = 0 disables bitrate filtering.
    // preferHighBitrate sorts API results by bitrate before local filtering.
    void searchStations(const QString &query,
                        int limit = 50,
                        int minBitrate = 0,
                        bool preferHighBitrate = false);

    // Looks for the highest-bitrate public stream matching a station name.
    void findBestQualityVariant(const QString &stationName, int minBitrate);

    // Recovery helper: finds another, more broadly compatible stream for the
    // same station after the current URL repeatedly disconnects.
    void findStableVariant(const QString &stationName, const QString &currentUrl);

signals:
    void searchStarted();
    void searchFinished(const QList<Station> &stations);
    void searchFailed(const QString &message);

    void qualityVariantFound(const Station &station);
    void qualityVariantUnavailable(const QString &message);

    void stableVariantFound(const Station &station);
    void stableVariantUnavailable(const QString &message);

private:
    QNetworkAccessManager m_network;
};
