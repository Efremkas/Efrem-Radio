#include "AddStationDialog.h"

#include <QVBoxLayout>
#include <QFormLayout>
#include <QLineEdit>
#include <QDialogButtonBox>
#include <QMessageBox>
#include <QUrl>

AddStationDialog::AddStationDialog(QWidget *parent) : QDialog(parent) {
    setWindowTitle("Добавить радиостанцию");
    setMinimumWidth(430);

    auto *layout = new QVBoxLayout(this);
    auto *form = new QFormLayout;
    m_name = new QLineEdit(this);
    m_url = new QLineEdit(this);
    m_name->setPlaceholderText("Например: Моё радио");
    m_url->setPlaceholderText("https://example.com/live.mp3");
    form->addRow("Название:", m_name);
    form->addRow("Stream URL:", m_url);
    layout->addLayout(form);

    auto *buttons = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel, this);
    connect(buttons, &QDialogButtonBox::accepted, this, &AddStationDialog::validateAndAccept);
    connect(buttons, &QDialogButtonBox::rejected, this, &QDialog::reject);
    layout->addWidget(buttons);
}

void AddStationDialog::validateAndAccept() {
    const QString name = m_name->text().trimmed();
    const QUrl url = QUrl::fromUserInput(m_url->text().trimmed());
    if (name.isEmpty() || !url.isValid() || url.scheme().isEmpty()) {
        QMessageBox::warning(this, "Проверьте данные", "Укажите название и корректный URL аудиопотока.");
        return;
    }
    accept();
}

Station AddStationDialog::station() const {
    Station s;
    s.name = m_name->text().trimmed();
    s.streamUrl = QUrl::fromUserInput(m_url->text().trimmed()).toString();
    s.custom = true;
    s.codec = "URL";
    return s;
}
