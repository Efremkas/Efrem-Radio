#pragma once

#include <QMainWindow>
#include <QList>
#include "Station.h"

class QLineEdit;
class QPushButton;
class QListWidget;
class QLabel;
class QSlider;
class QTabWidget;
class QListWidgetItem;

class RadioApi;
class RadioPlayer;
class StationStore;
class TrayManager;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void runSearch();
    void playSelected(QListWidgetItem *item);
    void addManualStation();
    void toggleCurrentFavorite();
    void refreshSavedLists();
    void setHighQualityEnabled(bool enabled);
    void refreshHighQualityForCurrent();

private:
    QWidget *buildSearchPage();
    QWidget *buildListPage(QListWidget *&list, const QString &emptyText);
    QWidget *buildPlayerBar();
    void populateList(QListWidget *list, const QList<Station> &stations, const QString &emptyText);
    Station stationFromItem(QListWidgetItem *item) const;
    void playStation(const Station &station);
    void updateFavoriteButton();
    void updateHighQualityUi();
    void applyStyle();

    RadioApi *m_api;
    RadioPlayer *m_player;
    StationStore *m_store;
    TrayManager *m_tray;

    QLineEdit *m_searchEdit = nullptr;
    QPushButton *m_searchButton = nullptr;
    QListWidget *m_searchResults = nullptr;
    QListWidget *m_favorites = nullptr;
    QListWidget *m_custom = nullptr;
    QListWidget *m_history = nullptr;

    QLabel *m_nowName = nullptr;
    QLabel *m_nowMeta = nullptr;
    QLabel *m_status = nullptr;
    QPushButton *m_playPause = nullptr;
    QPushButton *m_favoriteButton = nullptr;
    QPushButton *m_hqButton = nullptr;
    QSlider *m_bitrateSlider = nullptr;
    QLabel *m_bitrateValue = nullptr;
    QSlider *m_volume = nullptr;
    bool m_stableRecoveryInProgress = false;
};
