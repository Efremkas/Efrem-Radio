#include "MainWindow.h"
#include "RadioApi.h"
#include "RadioPlayer.h"
#include "StationStore.h"
#include "AddStationDialog.h"
#include "TrayManager.h"

#include <QApplication>
#include <QCloseEvent>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QListWidget>
#include <QLabel>
#include <QSlider>
#include <QTabWidget>
#include <QMessageBox>
#include <QSettings>
#include <QStyle>
#include <QToolButton>
#include <QFrame>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    setWindowTitle("Efrem Radio");
    resize(980, 680);
    setMinimumSize(760, 520);

    m_api = new RadioApi(this);
    m_player = new RadioPlayer(this);
    m_store = new StationStore(this);

    auto *central = new QWidget(this);
    auto *root = new QVBoxLayout(central);
    root->setContentsMargins(18, 18, 18, 18);
    root->setSpacing(14);

    auto *header = new QHBoxLayout;
    auto *title = new QLabel("Efrem Radio", this);
    title->setObjectName("appTitle");
    auto *subtitle = new QLabel("Интернет-радио без браузера", this);
    subtitle->setObjectName("appSubtitle");
    auto *titleCol = new QVBoxLayout;
    titleCol->setSpacing(0);
    titleCol->addWidget(title);
    titleCol->addWidget(subtitle);
    header->addLayout(titleCol);
    header->addStretch();

    auto *addButton = new QPushButton("+ Добавить станцию", this);
    addButton->setObjectName("secondaryButton");
    connect(addButton, &QPushButton::clicked, this, &MainWindow::addManualStation);
    header->addWidget(addButton);
    root->addLayout(header);

    auto *tabs = new QTabWidget(this);
    tabs->addTab(buildSearchPage(), "Поиск");
    tabs->addTab(buildListPage(m_favorites, "Избранных станций пока нет"), "Избранное");
    tabs->addTab(buildListPage(m_custom, "Добавьте свой stream URL"), "Мои станции");
    tabs->addTab(buildListPage(m_history, "История прослушивания пуста"), "История");
    root->addWidget(tabs, 1);
    root->addWidget(buildPlayerBar());

    setCentralWidget(central);
    applyStyle();

    m_tray = new TrayManager(this, m_player, this);

    connect(m_searchEdit, &QLineEdit::returnPressed, this, &MainWindow::runSearch);
    connect(m_searchButton, &QPushButton::clicked, this, &MainWindow::runSearch);

    connect(m_api, &RadioApi::searchStarted, this, [this]() {
        m_status->setText("Поиск радиостанций...");
        m_searchButton->setEnabled(false);
    });
    connect(m_api, &RadioApi::searchFinished, this, [this](const QList<Station> &stations) {
        m_searchButton->setEnabled(true);
        populateList(m_searchResults, stations, "Ничего не найдено");
        m_status->setText(QString("Найдено: %1").arg(stations.size()));
    });
    connect(m_api, &RadioApi::searchFailed, this, [this](const QString &msg) {
        m_searchButton->setEnabled(true);
        m_status->setText("Ошибка поиска");
        QMessageBox::warning(this, "Каталог радиостанций", msg);
    });
    connect(m_api, &RadioApi::qualityVariantFound, this, [this](const Station &station) {
        if (!m_hqButton || !m_hqButton->isChecked()) return;
        const Station current = m_player->currentStation();
        if (current.isValid() && current.streamUrl == station.streamUrl) {
            m_status->setText(QString("Текущий поток уже соответствует HQ: %1 kbps").arg(station.bitrate));
            return;
        }
        m_player->play(station);
        m_status->setText(QString("HQ-поток найден: %1 kbps").arg(station.bitrate));
    });
    connect(m_api, &RadioApi::qualityVariantUnavailable, this, [this](const QString &msg) {
        if (m_hqButton && m_hqButton->isChecked())
            m_status->setText("HQ: " + msg + " Текущий поток оставлен без изменений.");
    });

    connect(m_api, &RadioApi::stableVariantFound, this, [this](const Station &station) {
        m_stableRecoveryInProgress = false;
        if (!station.isValid()) return;
        m_status->setText(QString("Нестабильный поток заменён на более совместимый: %1 %2 kbps")
                              .arg(station.codec.isEmpty() ? QStringLiteral("поток") : station.codec)
                              .arg(station.bitrate));
        m_player->play(station);
    });
    connect(m_api, &RadioApi::stableVariantUnavailable, this, [this](const QString &msg) {
        m_stableRecoveryInProgress = false;
        m_status->setText("Поток этой станции нестабилен. " + msg);
    });

    connect(m_player, &RadioPlayer::stationChanged, this, [this](const Station &s) {
        m_nowName->setText(s.name);
        QStringList meta;
        if (!s.country.isEmpty()) meta << s.country;
        if (!s.codec.isEmpty()) meta << s.codec;
        if (s.bitrate > 0) meta << QString("%1 kbps").arg(s.bitrate);
        m_nowMeta->setText(meta.join(" • "));
        m_store->addToHistory(s);
        updateFavoriteButton();
    });
    connect(m_player, &RadioPlayer::playbackStateChanged, this, [this](bool playing) {
        m_playPause->setText(playing ? "Пауза" : "Воспроизвести");
    });
    connect(m_player, &RadioPlayer::errorOccurred, this, [this](const QString &msg) {
        // Network-radio errors are normally handled by RadioPlayer's automatic
        // reconnect logic. Keep the UI non-blocking; the status bar contains
        // the useful diagnostic text if a station remains unavailable.
        m_status->setText("Ошибка потока: " + msg);
    });
    connect(m_player, &RadioPlayer::mediaStatusText, m_status, &QLabel::setText);
    connect(m_player, &RadioPlayer::streamUnstable, this, [this](const Station &station, const QString &reason) {
        if (m_stableRecoveryInProgress || !station.isValid() || station.custom)
            return;
        m_stableRecoveryInProgress = true;
        m_status->setText(QString("Поток несколько раз оборвался (%1). Ищу более стабильную версию...").arg(reason));
        m_api->findStableVariant(station.name, station.streamUrl);
    });
    connect(m_playPause, &QPushButton::clicked, m_player, &RadioPlayer::toggle);
    connect(m_favoriteButton, &QPushButton::clicked, this, &MainWindow::toggleCurrentFavorite);
    connect(m_volume, &QSlider::valueChanged, m_player, &RadioPlayer::setVolume);
    connect(m_hqButton, &QPushButton::toggled, this, &MainWindow::setHighQualityEnabled);
    connect(m_bitrateSlider, &QSlider::valueChanged, this, [this](int) { updateHighQualityUi(); });
    connect(m_bitrateSlider, &QSlider::sliderReleased, this, [this]() {
        if (m_hqButton->isChecked()) {
            refreshHighQualityForCurrent();
            if (!m_searchEdit->text().trimmed().isEmpty()) runSearch();
        }
    });

    connect(m_store, &StationStore::favoritesChanged, this, &MainWindow::refreshSavedLists);
    connect(m_store, &StationStore::customStationsChanged, this, &MainWindow::refreshSavedLists);
    connect(m_store, &StationStore::historyChanged, this, &MainWindow::refreshSavedLists);

    refreshSavedLists();

    QSettings s;
    m_volume->setValue(s.value("audio/volume", 50).toInt());
    m_player->setVolume(m_volume->value());
    m_bitrateSlider->setValue(qBound(128, s.value("audio/hqMinBitrate", 320).toInt(), 1441));
    m_hqButton->setChecked(s.value("audio/hqEnabled", false).toBool());
    updateHighQualityUi();
}

MainWindow::~MainWindow() {
    QSettings s;
    s.setValue("audio/volume", m_volume->value());
    s.setValue("audio/hqEnabled", m_hqButton->isChecked());
    s.setValue("audio/hqMinBitrate", m_bitrateSlider->value());
}

QWidget *MainWindow::buildSearchPage() {
    auto *page = new QWidget(this);
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(6, 12, 6, 6);
    layout->setSpacing(10);

    auto *searchRow = new QHBoxLayout;
    m_searchEdit = new QLineEdit(page);
    m_searchEdit->setPlaceholderText("Название станции, например: Europa Plus, Jazz, Rock...");
    m_searchButton = new QPushButton("Найти", page);
    m_searchButton->setObjectName("primaryButton");
    searchRow->addWidget(m_searchEdit, 1);
    searchRow->addWidget(m_searchButton);
    layout->addLayout(searchRow);

    m_searchResults = new QListWidget(page);
    m_searchResults->setAlternatingRowColors(false);
    m_searchResults->setSpacing(4);
    connect(m_searchResults, &QListWidget::itemDoubleClicked, this, &MainWindow::playSelected);
    layout->addWidget(m_searchResults, 1);

    auto *hint = new QLabel("Двойной клик по станции — начать воспроизведение", page);
    hint->setObjectName("hint");
    layout->addWidget(hint);
    return page;
}

QWidget *MainWindow::buildListPage(QListWidget *&list, const QString &emptyText) {
    Q_UNUSED(emptyText);
    auto *page = new QWidget(this);
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(6, 12, 6, 6);
    list = new QListWidget(page);
    list->setSpacing(4);
    connect(list, &QListWidget::itemDoubleClicked, this, &MainWindow::playSelected);
    layout->addWidget(list);
    return page;
}

QWidget *MainWindow::buildPlayerBar() {
    auto *frame = new QFrame(this);
    frame->setObjectName("playerBar");
    auto *layout = new QHBoxLayout(frame);
    layout->setContentsMargins(16, 12, 16, 12);

    auto *info = new QVBoxLayout;
    m_nowName = new QLabel("Радиостанция не выбрана", frame);
    m_nowName->setObjectName("nowName");
    m_nowMeta = new QLabel("Найдите станцию или добавьте свой поток", frame);
    m_nowMeta->setObjectName("nowMeta");
    m_status = new QLabel("Готово", frame);
    m_status->setObjectName("statusText");
    info->addWidget(m_nowName);
    info->addWidget(m_nowMeta);
    info->addWidget(m_status);
    layout->addLayout(info, 1);

    m_favoriteButton = new QPushButton("☆ В избранное", frame);
    m_favoriteButton->setObjectName("secondaryButton");
    layout->addWidget(m_favoriteButton);

    auto *hqBox = new QVBoxLayout;
    hqBox->setSpacing(3);
    auto *hqTop = new QHBoxLayout;
    hqTop->setSpacing(6);
    m_hqButton = new QPushButton("HQ выкл", frame);
    m_hqButton->setObjectName("hqButton");
    m_hqButton->setCheckable(true);
    m_hqButton->setToolTip("Ищет и предпочитает реальные потоки с высоким битрейтом. Не повышает качество исходного низкобитрейтного потока.");
    hqTop->addWidget(m_hqButton);
    m_bitrateValue = new QLabel("≥ 320 kbps", frame);
    m_bitrateValue->setObjectName("hqValue");
    hqTop->addWidget(m_bitrateValue);
    hqBox->addLayout(hqTop);

    m_bitrateSlider = new QSlider(Qt::Horizontal, frame);
    m_bitrateSlider->setRange(128, 1441);
    m_bitrateSlider->setSingleStep(1);
    m_bitrateSlider->setPageStep(64);
    m_bitrateSlider->setTickInterval(128);
    m_bitrateSlider->setFixedWidth(170);
    m_bitrateSlider->setToolTip("Минимальный предпочитаемый битрейт. Диапазон 128–1441 kbps; значения выше 320 kbps обычно встречаются у lossless/FLAC-потоков.");
    hqBox->addWidget(m_bitrateSlider);
    layout->addLayout(hqBox);

    m_playPause = new QPushButton("Воспроизвести", frame);
    m_playPause->setObjectName("primaryButton");
    layout->addWidget(m_playPause);

    auto *volLabel = new QLabel("Громкость", frame);
    volLabel->setObjectName("hint");
    layout->addWidget(volLabel);
    m_volume = new QSlider(Qt::Horizontal, frame);
    m_volume->setRange(0, 100);
    m_volume->setFixedWidth(120);
    layout->addWidget(m_volume);
    return frame;
}

void MainWindow::runSearch() {
    const bool hq = m_hqButton && m_hqButton->isChecked();
    const int minBitrate = hq ? m_bitrateSlider->value() : 0;
    m_api->searchStations(m_searchEdit->text(), 50, minBitrate, hq);
}

void MainWindow::playSelected(QListWidgetItem *item) {
    if (!item) return;
    playStation(stationFromItem(item));
}

void MainWindow::playStation(const Station &station) {
    if (!station.isValid()) return;
    m_player->play(station);
}

Station MainWindow::stationFromItem(QListWidgetItem *item) const {
    return Station::fromVariantMap(item->data(Qt::UserRole).toMap());
}

void MainWindow::populateList(QListWidget *list, const QList<Station> &stations, const QString &emptyText) {
    list->clear();
    if (stations.isEmpty()) {
        auto *item = new QListWidgetItem(emptyText, list);
        item->setFlags(Qt::NoItemFlags);
        return;
    }
    for (const auto &s : stations) {
        QStringList detail;
        if (!s.country.isEmpty()) detail << s.country;
        if (!s.language.isEmpty()) detail << s.language;
        if (!s.codec.isEmpty()) detail << s.codec;
        if (s.bitrate > 0) detail << QString("%1 kbps").arg(s.bitrate);
        QString text = s.name;
        if (!detail.isEmpty()) text += "\n" + detail.join(" • ");
        auto *item = new QListWidgetItem(text, list);
        item->setData(Qt::UserRole, s.toVariantMap());
        item->setToolTip(s.streamUrl);
        item->setSizeHint(QSize(0, 50));
    }
}

void MainWindow::addManualStation() {
    AddStationDialog dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        Station s = dlg.station();
        m_store->addCustomStation(s);
        playStation(s);
    }
}

void MainWindow::toggleCurrentFavorite() {
    const Station s = m_player->currentStation();
    if (!s.isValid()) {
        QMessageBox::information(this, "Избранное", "Сначала выберите радиостанцию.");
        return;
    }
    m_store->toggleFavorite(s);
    updateFavoriteButton();
}

void MainWindow::updateFavoriteButton() {
    const Station s = m_player->currentStation();
    if (!s.isValid()) {
        m_favoriteButton->setText("☆ В избранное");
        return;
    }
    m_favoriteButton->setText(m_store->isFavorite(s) ? "★ В избранном" : "☆ В избранное");
}

void MainWindow::refreshSavedLists() {
    populateList(m_favorites, m_store->favorites(), "Избранных станций пока нет");
    populateList(m_custom, m_store->customStations(), "Добавьте свой stream URL");
    populateList(m_history, m_store->history(), "История прослушивания пуста");
}

void MainWindow::setHighQualityEnabled(bool enabled) {
    updateHighQualityUi();
    if (enabled) {
        m_status->setText(QString("HQ включен: предпочитаю потоки ≥ %1 kbps").arg(m_bitrateSlider->value()));
        refreshHighQualityForCurrent();
    } else {
        m_status->setText("HQ выключен: обычный поиск радиостанций");
    }

    if (!m_searchEdit->text().trimmed().isEmpty())
        runSearch();
}

void MainWindow::refreshHighQualityForCurrent() {
    if (!m_hqButton || !m_hqButton->isChecked()) return;
    const Station current = m_player->currentStation();
    if (!current.isValid()) return;

    const int target = m_bitrateSlider->value();
    if (current.bitrate >= target) {
        m_status->setText(QString("HQ: текущий поток %1 kbps уже соответствует порогу").arg(current.bitrate));
        return;
    }

    m_status->setText(QString("Ищу HQ-версию «%1» ≥ %2 kbps...").arg(current.name).arg(target));
    m_api->findBestQualityVariant(current.name, target);
}

void MainWindow::updateHighQualityUi() {
    if (!m_hqButton || !m_bitrateSlider || !m_bitrateValue) return;
    m_bitrateValue->setText(QString("≥ %1 kbps").arg(m_bitrateSlider->value()));
    m_hqButton->setText(m_hqButton->isChecked() ? "HQ вкл" : "HQ выкл");
    m_bitrateSlider->setEnabled(m_hqButton->isChecked());
}

void MainWindow::closeEvent(QCloseEvent *event) {
    if (m_tray && m_tray->trayIcon()->isVisible()) {
        hide();
        m_tray->trayIcon()->showMessage("Efrem Radio", "Приложение продолжает работать в трее.", QSystemTrayIcon::Information, 1800);
        event->ignore();
    } else {
        event->accept();
    }
}

void MainWindow::applyStyle() {
    setStyleSheet(R"(
        QMainWindow, QWidget { background: #101318; color: #eef2f7; font-family: "Segoe UI"; font-size: 10.5pt; }
        #appTitle { font-size: 24pt; font-weight: 700; color: white; }
        #appSubtitle, #hint, #nowMeta, #statusText { color: #8f9aaa; }
        #nowName { font-size: 13pt; font-weight: 650; color: white; }
        QTabWidget::pane { border: 1px solid #252b34; border-radius: 10px; background: #151a21; }
        QTabBar::tab { background: #151a21; color: #9da7b5; padding: 9px 16px; border: none; }
        QTabBar::tab:selected { color: white; border-bottom: 2px solid #4da3ff; }
        QLineEdit { background: #0d1116; border: 1px solid #2a313b; border-radius: 9px; padding: 10px 12px; selection-background-color: #357ec7; }
        QLineEdit:focus { border-color: #4da3ff; }
        QPushButton { border: 1px solid #303845; border-radius: 9px; padding: 9px 14px; background: #1b222c; color: #f3f6fa; }
        QPushButton:hover { background: #232d39; }
        #primaryButton { background: #2878c8; border-color: #2878c8; font-weight: 600; }
        #primaryButton:hover { background: #3188dd; }
        #secondaryButton { background: #171d25; }
        #hqButton { background: #171d25; min-width: 70px; font-weight: 650; }
        #hqButton:checked { background: #184f3a; border-color: #2e9b6d; color: #dfffee; }
        #hqValue { color: #8fd8b8; font-size: 9pt; }
        QListWidget { background: #11161c; border: 1px solid #252b34; border-radius: 9px; padding: 6px; outline: 0; }
        QListWidget::item { background: #171d25; border: 1px solid #232a34; border-radius: 8px; padding: 8px 10px; margin: 2px; }
        QListWidget::item:selected { background: #203958; border-color: #3f79b1; }
        QListWidget::item:hover { background: #1c2530; }
        #playerBar { background: #151a21; border: 1px solid #252b34; border-radius: 12px; }
        QSlider::groove:horizontal { height: 5px; background: #2a313b; border-radius: 2px; }
        QSlider::handle:horizontal { width: 14px; margin: -5px 0; background: #4da3ff; border-radius: 7px; }
        QSlider::sub-page:horizontal { background: #357fc4; border-radius: 2px; }
    )");
}
