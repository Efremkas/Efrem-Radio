#include "RadioApi.h"

#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>
#include <QUrlQuery>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <algorithm>

namespace {
Station stationFromJson(const QJsonObject &o) {
    Station s;
    s.id = o.value("stationuuid").toString();
    s.name = o.value("name").toString().trimmed();
    s.streamUrl = o.value("url_resolved").toString();
    if (s.streamUrl.isEmpty()) s.streamUrl = o.value("url").toString();
    s.homepage = o.value("homepage").toString();
    s.favicon = o.value("favicon").toString();
    s.country = o.value("country").toString();
    s.language = o.value("language").toString();
    s.codec = o.value("codec").toString();
    s.bitrate = o.value("bitrate").toInt();
    s.custom = false;
    return s;
}

QNetworkRequest makeRequest(const QUrl &url) {
    QNetworkRequest req(url);
    req.setHeader(QNetworkRequest::UserAgentHeader,
                  "EfremRadio/1.1 (Qt 6 desktop radio player)");
    req.setRawHeader("Accept", "application/json");
    return req;
}
}

RadioApi::RadioApi(QObject *parent) : QObject(parent) {}

void RadioApi::searchStations(const QString &query,
                              int limit,
                              int minBitrate,
                              bool preferHighBitrate) {
    const QString trimmed = query.trimmed();
    if (trimmed.isEmpty()) {
        emit searchFinished({});
        return;
    }

    emit searchStarted();

    QUrl url("https://all.api.radio-browser.info/json/stations/search");
    QUrlQuery q;
    q.addQueryItem("name", trimmed);
    q.addQueryItem("nameExact", "false");
    q.addQueryItem("hidebroken", "true");
    q.addQueryItem("order", preferHighBitrate ? "bitrate" : "clickcount");
    q.addQueryItem("reverse", "true");

    // Fetch extra candidates in HQ mode, then filter locally. This keeps the
    // feature robust even if a Radio Browser mirror ignores bitrateMin.
    const int requested = qBound(1, limit, 100);
    const int apiLimit = preferHighBitrate ? qMax(requested, 100) : requested;
    q.addQueryItem("limit", QString::number(qMin(apiLimit, 100)));
    if (minBitrate > 0)
        q.addQueryItem("bitrateMin", QString::number(minBitrate));
    url.setQuery(q);

    QNetworkReply *reply = m_network.get(makeRequest(url));
    connect(reply, &QNetworkReply::finished, this,
            [this, reply, requested, minBitrate, preferHighBitrate]() {
        if (reply->error() != QNetworkReply::NoError) {
            const QString error = reply->errorString();
            reply->deleteLater();
            emit searchFailed(error);
            return;
        }

        const QJsonDocument doc = QJsonDocument::fromJson(reply->readAll());
        reply->deleteLater();
        if (!doc.isArray()) {
            emit searchFailed("Некорректный ответ каталога радиостанций.");
            return;
        }

        QList<Station> result;
        for (const QJsonValue &v : doc.array()) {
            if (!v.isObject()) continue;
            const Station s = stationFromJson(v.toObject());
            if (!s.isValid()) continue;
            if (minBitrate > 0 && s.bitrate < minBitrate) continue;
            result.push_back(s);
        }

        if (preferHighBitrate) {
            std::sort(result.begin(), result.end(), [](const Station &a, const Station &b) {
                return a.bitrate > b.bitrate;
            });
        }
        if (result.size() > requested)
            result = result.mid(0, requested);

        emit searchFinished(result);
    });
}

void RadioApi::findBestQualityVariant(const QString &stationName, int minBitrate) {
    const QString trimmed = stationName.trimmed();
    if (trimmed.isEmpty()) {
        emit qualityVariantUnavailable("Название текущей станции неизвестно.");
        return;
    }

    QUrl url("https://all.api.radio-browser.info/json/stations/search");
    QUrlQuery q;
    q.addQueryItem("name", trimmed);
    q.addQueryItem("nameExact", "false");
    q.addQueryItem("hidebroken", "true");
    q.addQueryItem("order", "bitrate");
    q.addQueryItem("reverse", "true");
    q.addQueryItem("limit", "100");
    if (minBitrate > 0)
        q.addQueryItem("bitrateMin", QString::number(minBitrate));
    url.setQuery(q);

    QNetworkReply *reply = m_network.get(makeRequest(url));
    connect(reply, &QNetworkReply::finished, this,
            [this, reply, minBitrate]() {
        if (reply->error() != QNetworkReply::NoError) {
            const QString error = reply->errorString();
            reply->deleteLater();
            emit qualityVariantUnavailable(error);
            return;
        }

        const QJsonDocument doc = QJsonDocument::fromJson(reply->readAll());
        reply->deleteLater();
        if (!doc.isArray()) {
            emit qualityVariantUnavailable("Каталог вернул некорректный ответ.");
            return;
        }

        Station best;
        for (const QJsonValue &v : doc.array()) {
            if (!v.isObject()) continue;
            const Station candidate = stationFromJson(v.toObject());
            if (!candidate.isValid()) continue;
            if (candidate.bitrate < minBitrate) continue;
            if (!best.isValid() || candidate.bitrate > best.bitrate)
                best = candidate;
        }

        if (best.isValid()) {
            emit qualityVariantFound(best);
        } else {
            emit qualityVariantUnavailable(
                QString("Поток с битрейтом не ниже %1 kbps не найден.").arg(minBitrate));
        }
    });
}

void RadioApi::findStableVariant(const QString &stationName, const QString &currentUrl) {
    const QString trimmed = stationName.trimmed();
    if (trimmed.isEmpty()) {
        emit stableVariantUnavailable("Название станции неизвестно.");
        return;
    }

    QUrl url("https://all.api.radio-browser.info/json/stations/search");
    QUrlQuery q;
    q.addQueryItem("name", trimmed);
    q.addQueryItem("nameExact", "false");
    q.addQueryItem("hidebroken", "true");
    q.addQueryItem("order", "clickcount");
    q.addQueryItem("reverse", "true");
    q.addQueryItem("limit", "100");
    url.setQuery(q);

    QNetworkReply *reply = m_network.get(makeRequest(url));
    connect(reply, &QNetworkReply::finished, this,
            [this, reply, currentUrl]() {
        if (reply->error() != QNetworkReply::NoError) {
            const QString error = reply->errorString();
            reply->deleteLater();
            emit stableVariantUnavailable(error);
            return;
        }

        const QJsonDocument doc = QJsonDocument::fromJson(reply->readAll());
        reply->deleteLater();
        if (!doc.isArray()) {
            emit stableVariantUnavailable("Каталог вернул некорректный ответ.");
            return;
        }

        Station best;
        int bestScore = -100000;

        for (const QJsonValue &v : doc.array()) {
            if (!v.isObject()) continue;
            const QJsonObject o = v.toObject();
            Station s = stationFromJson(o);
            if (!s.isValid() || s.streamUrl == currentUrl) continue;
            if (!o.value("lastcheckok").toBool(true)) continue;

            const QString codec = s.codec.trimmed().toUpper();
            int score = 0;

            // Prefer formats that Qt/FFmpeg and radio servers tend to handle
            // most consistently for long-running live playback.
            if (codec.contains("AAC")) score += 120;
            else if (codec.contains("MP3") || codec.contains("MPEG")) score += 115;
            else if (codec.contains("OPUS")) score += 80;
            else if (codec.contains("OGG") || codec.contains("VORBIS")) score += 65;
            else if (codec.contains("FLAC")) score += 45;
            else score += 30;

            if (s.bitrate >= 128 && s.bitrate <= 320) score += 45;
            else if (s.bitrate > 320 && s.bitrate <= 512) score += 25;
            else if (s.bitrate > 512) score += 5;
            else if (s.bitrate > 0) score += 10;

            score += qMin(40, o.value("votes").toInt() / 2);
            score += qMin(40, o.value("clickcount").toInt() / 500);

            if (score > bestScore) {
                bestScore = score;
                best = s;
            }
        }

        if (best.isValid())
            emit stableVariantFound(best);
        else
            emit stableVariantUnavailable("Альтернативный стабильный поток для этой станции не найден.");
    });
}
