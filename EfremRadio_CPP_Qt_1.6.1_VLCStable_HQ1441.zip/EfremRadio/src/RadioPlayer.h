#pragma once

#include <QObject>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QElapsedTimer>
#include <QTimer>
#include "Station.h"

class VlcBackend;

class RadioPlayer : public QObject {
    Q_OBJECT
public:
    explicit RadioPlayer(QObject *parent = nullptr);

    void play(const Station &station);
    void pause();
    void resume();
    void stop();
    void toggle();
    void setVolume(int percent);

    bool isPlaying() const;
    int volume() const;
    Station currentStation() const { return m_current; }
    bool usingVlc() const { return m_useVlc; }
    QString engineDescription() const;

signals:
    void stationChanged(const Station &station);
    void playbackStateChanged(bool playing);
    void errorOccurred(const QString &message);
    void mediaStatusText(const QString &text);
    void streamUnstable(const Station &station, const QString &reason);

private:
    void setupQtFallback();
    void scheduleReconnect(const QString &reason, int minimumDelayMs = 1500);
    void reconnectNow();

    VlcBackend *m_vlc = nullptr;
    bool m_useVlc = false;

    QMediaPlayer m_player;
    QAudioOutput m_audio;
    Station m_current;

    QTimer m_reconnectTimer;
    bool m_shouldPlay = false;
    bool m_userPaused = false;
    bool m_restarting = false;
    bool m_unstableReported = false;
    int m_reconnectAttempts = 0;
    int m_volume = 50;
};
