#include "VlcBackend.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QStandardPaths>
#include <QUrl>
#include <QtGlobal>

VlcBackend::VlcBackend(QObject *parent) : QObject(parent) {
    m_pollTimer.setInterval(250);
    connect(&m_pollTimer, &QTimer::timeout, this, [this]() {
        if (!m_shouldPlay || m_paused || !m_player || !pPlayerIsPlaying)
            return;

        const bool playing = pPlayerIsPlaying(m_player) != 0;
        if (playing) {
            m_notPlayingSince.invalidate();
            if (!m_everPlayed) {
                m_everPlayed = true;
                m_failureReported = false;
                emit started();
                emit statusText(QStringLiteral("Воспроизведение • VLC streaming engine"));
            }
            return;
        }

        // libVLC may report false while it is still opening/buffering. Give it
        // plenty of time before deciding that the stream really died.
        if (!m_everPlayed) {
            if (m_connectTimer.isValid() && m_connectTimer.elapsed() > 20000 && !m_failureReported) {
                m_failureReported = true;
                emit playbackFailed(vlcError(QStringLiteral("VLC не смог открыть поток за 20 секунд")));
            }
            return;
        }

        if (!m_notPlayingSince.isValid())
            m_notPlayingSince.start();

        // A short false state can be normal during buffering. Only report a
        // failure after five continuous seconds without playback.
        if (m_notPlayingSince.elapsed() > 5000 && !m_failureReported) {
            m_failureReported = true;
            emit playbackFailed(vlcError(QStringLiteral("аудиопоток остановился")));
        }
    });
}

VlcBackend::~VlcBackend() {
    stop();
    if (m_instance && pRelease)
        pRelease(m_instance);
    m_instance = nullptr;
    if (m_library.isLoaded())
        m_library.unload();
}

QString VlcBackend::findVlcLibrary() const {
    const QString appDir = QCoreApplication::applicationDirPath();
    const QString envHome = qEnvironmentVariable("VLC_HOME");

    QStringList candidates;
    if (!envHome.isEmpty())
        candidates << QDir(envHome).filePath("libvlc.dll");

    candidates << QDir(appDir).filePath("vlc/libvlc.dll")
               << QDir(appDir).filePath("runtime/vlc/libvlc.dll")
               << QStringLiteral("C:/Program Files/VideoLAN/VLC/libvlc.dll")
               << QStringLiteral("C:/Program Files (x86)/VideoLAN/VLC/libvlc.dll");

    for (const QString &path : candidates) {
        if (QFileInfo::exists(path))
            return QDir::cleanPath(path);
    }
    return {};
}

bool VlcBackend::resolveSymbols() {
#define RESOLVE_REQUIRED(member, symbol) \
    member = reinterpret_cast<decltype(member)>(m_library.resolve(symbol)); \
    if (!member) { m_lastError = QStringLiteral("Не найден символ libVLC: %1").arg(QStringLiteral(symbol)); return false; }

    RESOLVE_REQUIRED(pNew, "libvlc_new");
    RESOLVE_REQUIRED(pRelease, "libvlc_release");
    RESOLVE_REQUIRED(pMediaNewLocation, "libvlc_media_new_location");
    RESOLVE_REQUIRED(pMediaRelease, "libvlc_media_release");
    RESOLVE_REQUIRED(pPlayerNewFromMedia, "libvlc_media_player_new_from_media");
    RESOLVE_REQUIRED(pPlayerRelease, "libvlc_media_player_release");
    RESOLVE_REQUIRED(pPlayerPlay, "libvlc_media_player_play");
    RESOLVE_REQUIRED(pPlayerSetPause, "libvlc_media_player_set_pause");
    RESOLVE_REQUIRED(pPlayerIsPlaying, "libvlc_media_player_is_playing");
    RESOLVE_REQUIRED(pAudioSetVolume, "libvlc_audio_set_volume");

    pMediaAddOption = reinterpret_cast<FnMediaAddOption>(m_library.resolve("libvlc_media_add_option"));
    pPlayerStop = reinterpret_cast<FnPlayerStop>(m_library.resolve("libvlc_media_player_stop"));
    pErrmsg = reinterpret_cast<FnErrmsg>(m_library.resolve("libvlc_errmsg"));
#undef RESOLVE_REQUIRED
    return true;
}

bool VlcBackend::initialize() {
    if (m_instance)
        return true;

    if (qEnvironmentVariable("EFREM_RADIO_ENGINE").compare("qt", Qt::CaseInsensitive) == 0) {
        m_lastError = QStringLiteral("Qt backend выбран вручную");
        return false;
    }

    m_libraryPath = findVlcLibrary();
    if (m_libraryPath.isEmpty()) {
        m_lastError = QStringLiteral("libVLC не найден. Установите VLC 64-bit или задайте VLC_HOME.");
        return false;
    }

    const QString vlcDir = QFileInfo(m_libraryPath).absolutePath();
    const QString pluginsDir = QDir(vlcDir).filePath("plugins");
    qputenv("VLC_PLUGIN_PATH", QDir::toNativeSeparators(pluginsDir).toLocal8Bit());

    // Make libvlccore.dll and codec/plugin dependencies discoverable when
    // libvlc.dll is loaded from Program Files or from a portable runtime.
    QByteArray path = qgetenv("PATH");
    const QByteArray vlcDirBytes = QDir::toNativeSeparators(vlcDir).toLocal8Bit();
    if (!path.startsWith(vlcDirBytes + ';'))
        qputenv("PATH", vlcDirBytes + ';' + path);

    m_library.setFileName(m_libraryPath);
    if (!m_library.load()) {
        m_lastError = QStringLiteral("Не удалось загрузить libVLC: %1").arg(m_library.errorString());
        return false;
    }
    if (!resolveSymbols()) {
        m_library.unload();
        return false;
    }

    const char *args[] = {
        "--intf=dummy",
        "--no-video",
        "--quiet",
        "--network-caching=3000",
        "--live-caching=3000",
        "--no-video-title-show"
    };
    m_instance = pNew(static_cast<int>(sizeof(args) / sizeof(args[0])), args);
    if (!m_instance) {
        m_lastError = vlcError(QStringLiteral("libVLC не удалось инициализировать"));
        m_library.unload();
        return false;
    }

    m_pollTimer.start();
    return true;
}

QString VlcBackend::vlcError(const QString &fallback) const {
    if (pErrmsg) {
        const char *msg = pErrmsg();
        if (msg && *msg)
            return QString::fromUtf8(msg);
    }
    return fallback;
}

void VlcBackend::destroyPlayer() {
    if (m_player) {
        if (pPlayerStop)
            pPlayerStop(m_player);
        if (pPlayerRelease)
            pPlayerRelease(m_player);
        m_player = nullptr;
    }
    if (m_media && pMediaRelease) {
        pMediaRelease(m_media);
        m_media = nullptr;
    }
}

bool VlcBackend::play(const QString &url) {
    if (!m_instance || url.trimmed().isEmpty())
        return false;

    destroyPlayer();
    m_url = url.trimmed();
    m_shouldPlay = true;
    m_paused = false;
    m_everPlayed = false;
    m_failureReported = false;
    m_notPlayingSince.invalidate();
    m_connectTimer.restart();

    const QByteArray utf8Url = QUrl::fromUserInput(m_url).toString(QUrl::FullyEncoded).toUtf8();
    m_media = pMediaNewLocation(m_instance, utf8Url.constData());
    if (!m_media) {
        m_lastError = vlcError(QStringLiteral("Не удалось создать VLC media"));
        return false;
    }

    if (pMediaAddOption) {
        pMediaAddOption(m_media, ":network-caching=3000");
        pMediaAddOption(m_media, ":live-caching=3000");
        pMediaAddOption(m_media, ":http-reconnect=true");
    }

    m_player = pPlayerNewFromMedia(m_media);
    if (!m_player) {
        m_lastError = vlcError(QStringLiteral("Не удалось создать VLC player"));
        destroyPlayer();
        return false;
    }

    pAudioSetVolume(m_player, qBound(0, m_volume, 100));
    emit statusText(QStringLiteral("Подключение к радиостанции через VLC..."));
    const int result = pPlayerPlay(m_player);
    if (result != 0) {
        m_lastError = vlcError(QStringLiteral("VLC отказался запускать поток"));
        destroyPlayer();
        return false;
    }
    return true;
}

void VlcBackend::pause() {
    if (!m_player || !pPlayerSetPause)
        return;
    m_paused = true;
    pPlayerSetPause(m_player, 1);
    emit statusText(QStringLiteral("Пауза"));
}

void VlcBackend::resume() {
    if (!m_player) {
        if (!m_url.isEmpty())
            play(m_url);
        return;
    }
    m_paused = false;
    m_shouldPlay = true;
    m_failureReported = false;
    m_notPlayingSince.invalidate();
    pPlayerSetPause(m_player, 0);
}

void VlcBackend::stop() {
    m_shouldPlay = false;
    m_paused = false;
    m_everPlayed = false;
    m_failureReported = false;
    m_notPlayingSince.invalidate();
    destroyPlayer();
}

void VlcBackend::setVolume(int percent) {
    m_volume = qBound(0, percent, 100);
    if (m_player && pAudioSetVolume)
        pAudioSetVolume(m_player, m_volume);
}

bool VlcBackend::isPlaying() const {
    return m_player && pPlayerIsPlaying && pPlayerIsPlaying(m_player) != 0;
}
